﻿
namespace Invoive_maker
{
    partial class editprofile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.editprofileownername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.editprofilecompanyname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.editprofileemailid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.editprofilephoneno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.editprofilecomapanyaddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.editprofileupload = new System.Windows.Forms.Button();
            this.editprofilesave = new System.Windows.Forms.Button();
            this.editprofilepictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.editprofilepictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(703, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Owner Name :";
            // 
            // editprofileownername
            // 
            this.editprofileownername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofileownername.Location = new System.Drawing.Point(933, 264);
            this.editprofileownername.Multiline = true;
            this.editprofileownername.Name = "editprofileownername";
            this.editprofileownername.Size = new System.Drawing.Size(340, 35);
            this.editprofileownername.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(703, 330);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Company Name :";
            // 
            // editprofilecompanyname
            // 
            this.editprofilecompanyname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofilecompanyname.Location = new System.Drawing.Point(933, 323);
            this.editprofilecompanyname.Multiline = true;
            this.editprofilecompanyname.Name = "editprofilecompanyname";
            this.editprofilecompanyname.Size = new System.Drawing.Size(340, 35);
            this.editprofilecompanyname.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(703, 388);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "E-mail Id :";
            // 
            // editprofileemailid
            // 
            this.editprofileemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofileemailid.Location = new System.Drawing.Point(933, 382);
            this.editprofileemailid.Multiline = true;
            this.editprofileemailid.Name = "editprofileemailid";
            this.editprofileemailid.Size = new System.Drawing.Size(340, 35);
            this.editprofileemailid.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(703, 444);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Phone No :";
            // 
            // editprofilephoneno
            // 
            this.editprofilephoneno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofilephoneno.Location = new System.Drawing.Point(933, 438);
            this.editprofilephoneno.Multiline = true;
            this.editprofilephoneno.Name = "editprofilephoneno";
            this.editprofilephoneno.Size = new System.Drawing.Size(340, 35);
            this.editprofilephoneno.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(703, 500);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(186, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Company Address :";
            // 
            // editprofilecomapanyaddress
            // 
            this.editprofilecomapanyaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofilecomapanyaddress.Location = new System.Drawing.Point(933, 493);
            this.editprofilecomapanyaddress.Multiline = true;
            this.editprofilecomapanyaddress.Name = "editprofilecomapanyaddress";
            this.editprofilecomapanyaddress.Size = new System.Drawing.Size(340, 35);
            this.editprofilecomapanyaddress.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(703, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "Company Address :";
            // 
            // editprofileupload
            // 
            this.editprofileupload.BackColor = System.Drawing.Color.Teal;
            this.editprofileupload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofileupload.ForeColor = System.Drawing.SystemColors.Control;
            this.editprofileupload.Location = new System.Drawing.Point(1155, 101);
            this.editprofileupload.Name = "editprofileupload";
            this.editprofileupload.Size = new System.Drawing.Size(118, 44);
            this.editprofileupload.TabIndex = 12;
            this.editprofileupload.Text = "Upload";
            this.editprofileupload.UseVisualStyleBackColor = false;
            // 
            // editprofilesave
            // 
            this.editprofilesave.BackColor = System.Drawing.Color.Teal;
            this.editprofilesave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editprofilesave.ForeColor = System.Drawing.SystemColors.Control;
            this.editprofilesave.Location = new System.Drawing.Point(1044, 546);
            this.editprofilesave.Name = "editprofilesave";
            this.editprofilesave.Size = new System.Drawing.Size(118, 46);
            this.editprofilesave.TabIndex = 13;
            this.editprofilesave.Text = "Save";
            this.editprofilesave.UseVisualStyleBackColor = false;
            // 
            // editprofilepictureBox
            // 
            this.editprofilepictureBox.Location = new System.Drawing.Point(933, 12);
            this.editprofilepictureBox.Name = "editprofilepictureBox";
            this.editprofilepictureBox.Size = new System.Drawing.Size(216, 208);
            this.editprofilepictureBox.TabIndex = 0;
            this.editprofilepictureBox.TabStop = false;
            // 
            // editprofile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1502, 727);
            this.Controls.Add(this.editprofilesave);
            this.Controls.Add(this.editprofileupload);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.editprofilecomapanyaddress);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.editprofilephoneno);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.editprofileemailid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.editprofilecompanyname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.editprofileownername);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.editprofilepictureBox);
            this.Name = "editprofile";
            this.Text = "editprofile";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.editprofile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.editprofilepictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox editprofilepictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox editprofileownername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox editprofilecompanyname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox editprofileemailid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox editprofilephoneno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox editprofilecomapanyaddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button editprofileupload;
        private System.Windows.Forms.Button editprofilesave;
    }
}